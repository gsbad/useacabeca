"""Função que varre todos os indices de um array e retorna seus valores identados"""
def array_ident(lista):
    for indice in lista:
        #Verifica se o argumento inserido é uma lista
        if isinstance(indice, list):
            # Retorna a função recursivamente
            array_ident(indice)
        else:
            # Imprime o item
            print(indice)
print("importado!")

""" ############ EXEMPLO DE USO ############
hobbies = [
    [
        "Animes", [
            "Dragon Ball", "Dragon Ball Z", "Dragon Ball GT", "Dragon Ball Super", "Yuyu Hakusho"
        ]
    ],
    [
    "Filmes", [
            "O Senhor dos anéis", "Interestelar", "Ex Machina", "O Homem transcendental"
        ]
    ],
    [
    "Jogos", [
        "God of war 4", "Skyrim", "South Park - A fenda que abunda força", "Final Fantasy 7"
        ]
    ],
    [
    "Séries", [
        "The Sopranos", "Breaking Bad", "Mr Robot", "Westworld"
        ]
    ],
    [
    "Livros", [
        "1984", "Hitler, Ian Kershaw", "Descobrindo o Linux", "Revolução dos bichos", "Admirável mundo novo"
        ]
    ],
    [
    "Programação", [
        "Python", "Javascript", "Angular.js", "Java"
        ]
    ],
    [
    "Projetos", [
        "Automação residencial", "Machine Learning"
        ]
    ]
]
"""