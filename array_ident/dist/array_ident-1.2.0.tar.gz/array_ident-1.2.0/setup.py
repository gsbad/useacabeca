from distutils.core import setup

setup(
    name = "array_ident",
    version = "1.2.0",
    py_modules = ["array_ident"],
    author = "gsbad",
    author_email= "gsbadbr@gmail.com",
    url="http://github.com/gsbad",
    description="Um identador de arrays"
)
